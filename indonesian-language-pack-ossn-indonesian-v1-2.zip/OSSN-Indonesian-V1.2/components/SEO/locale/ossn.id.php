<?php
/**
 * Open Source Social Network
 *
 * @package	SEO Component
 * @author    	Daniel Teich <dnlteich86@gmail.com>
 * @copyright	Component SEO 2019 by Daniel Teich
 * @license  	General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link    		http://www.opensource-socialnetwork.org/
 */

$id = array(
	'seocomponent:name' => 'Pengaturan SEO:',
	'seo' => 'Pengaturan SEO',
	'dropdown:auswahl' => '- Belum ada yang dipilih -',
	'seosenden:ok' => 'Pengaturan disimpan.',	
	'seosenden:nichtok' => 'Pengaturan TIDAK disimpan.',
	'meta:seitenname' => 'META - Judul Website.',
	'meta:seitenbeschreibung' => 'META - Deskripsi Website',
	'meta:autor' => 'META - Pemilik Website.',
	'meta:copyright' => 'META - Copyright/Hak Cipta.',
	'meta:keywords' => 'META - Kata Kunci Website',
	'meta:robots' => 'META - Robot Website (index, follow, noindex, nofollow, none, noarchive).',
	'meta:googlesiteverification' => 'META - Kunci untuk Google-Site-Verification.',
	'twitter:card' => 'Twitter - Tipe Kartu.',
	'twitter:image' => 'Twitter - URL Gambar untuk kartu Twitter.',
	'twitter:imagealt' => 'Twitter - Deskripsi Gambar kartu Twitter.',
	'twitter:seitentitel' => 'Twitter - Judul website untuk kartu Twitter',
	'twitter:description' => 'Twitter - Deskripsi website untuk kartu Twitter.',
	'opengraph:seitenurl' => 'Open Graph - Alamat Website',
	'opengraph:seitenname' => 'Open Graph - Judul Website',
	'opengraph:seitenbeschreibung' => 'Open Graph - Deskripsi Website',
	'opengraph:sprache' => 'Open Graph - Bahasa Website',
	'opengraph:seitentyp' => 'Open Graph - Jenis Website',
	'opengraph:image' => 'Open Graph - URL gambar untuk Open Graph',
	'opengraph:imagehttps' => 'Open Graph - Gambar HTTPS-URL untuk Open Graph.',
	'opengraph:imagebreite' => 'Open Graph - Lebar gambar dalam piksel.',
	'opengraph:imagehoehe' => 'Open Graph - Tinggi gambar dalam piksel.',
	'opengraph:imagealt' => 'Open Graph - Deskripsi Gambar',
	'opengraph:fbappid' => 'Facebook App-ID',
);

ossn_register_languages('id', $id);
