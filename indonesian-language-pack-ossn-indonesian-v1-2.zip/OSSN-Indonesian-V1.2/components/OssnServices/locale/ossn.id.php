<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@softlab24.com>
 * @copyright � SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$id = array(
			'ossnservices' => 'Layanan Website',
			'ossnservices:apikey' => 'API KEY (Harap Rahasiakan Kode Ini)',
			'ossnservices:regenerate:key' => 'Buat Ulang API KEY',
			'ossnservices:generated' => 'Dihasilkan',
			'ossnservices:invalidmethod' => 'Metode Tidak Valid',
			'ossnservices:success' => 'Permintaan Berhasil Dieksekusi',
			'ossnservices:noresponse' => 'Metode yang diminta tidak memiliki muatan untuk Anda',
			'ossnservices:nouser' => 'Tidak ada pengguna seperti itu',
			'ossnservices:usernotvalidated' => 'Pengguna tidak divalidasi',
			'ossnservices:invalidkeytoken' => 'Token API KEY tidak valid',
			'ossnservices:invalidversion' => 'Versi API tidak valid',
			'ossnservices:invalidemail' => 'Alamat Email Salah',
			'ossnservices:emailalreadyinuse' => 'Alamat email sudah digunakan, silakan gunakan alamat email yang berbeda',
			'ossnservices:invalidpassword' => 'Kata sandi salah, harap pastikan kata sandi memiliki panjang minimum %s',
			'ossnservices:usereditfailed' => 'Modifikasi pengguna telah gagal!',
			'ossnservices:useredit:mindetails' => 'Harap berikan new_email, new_first_name, new_last_name',
			'ossnservices:useradd:allfields' => 'Pastikan Anda mengisi semua bidang, tidak ada (%s)',
			'ossnservices:useradd:invalidgender' => 'Jenis kelamin tidak valid, harus laki-laki atau perempuan',
			'ossnservices:empty:field:one:more' => 'Satu atau lebih input yang diharapkan, kosong. Pastikan Anda mengirim semua input yang diperlukan',
			'ossnservices:comment:failed:add' => 'Tidak bisa menambahkan komentar',
			'ossnservices:componnt:notfound' => 'Satu atau beberapa komponen yang diperlukan untuk permintaan ini tidak dapat ditemukan di server jauh',
			'ossnservices:wall:failed:add' => 'Tidak dapat menambahkan pos dinding',
			'ossnservices:invalidoldpassword' => 'Kata sandi saat ini tidak valid',
			'ossnservices:invalidgroup' => 'Grup tidak valid',
			'ossnservices:groupnomembers' => 'Tidak ada anggota',
			'ossnservices:groupnorequests' => 'Tidak ada Permintaan',
			'ossnservices:invalidowner' => 'Pemilik Tidak Valid',
			'ossnservices:notification:cannotmark' => 'Tidak dapat menandai notifikasi sebagai sudah dibaca',
			'ossnservices:messagecannotblank' => 'Pesan tidak boleh kosong',
			'ossnservices:messagesendfailed' => 'Pesan tidak dapat dikirim',
			'ossnservices:messagedeletefailed' => 'Penghapusan pesan gagal',
			'ossnservices:cannotdelete:comment' => 'Tidak dapat menghapus komentar!',
			'ossnservices:cannotaddalbum:photo' => 'Tidak dapat menambahkan foto ke album',
			'ossnservices:cannotaddalbum' => 'Tidak dapat membuat album',
			'ossnservices:cannotdelete:photo' => 'Tidak bisa menghapus foto',
);
ossn_register_languages('id', $id);