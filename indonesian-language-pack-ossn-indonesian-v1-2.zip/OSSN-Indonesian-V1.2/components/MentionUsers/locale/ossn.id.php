<?php
 $id = array(
	'mention:post:created' => '%s Menyebut Anda dalam sebuah Postingan!',
	'mention:comment:created' => '%s Menyebut Anda dalam sebuah Komentar!',
	'ossn:notifications:mention:post:created' => '%s Menyebut Anda dalam sebuah Postingan!',
	'ossn:notifications:mention:comment:created' => '%s Menyebut Anda dalam sebuah Komentar!',	
);
ossn_register_languages('id', $id); 