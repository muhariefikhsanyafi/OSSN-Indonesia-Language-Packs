<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$id = array(
	'textareasupport' => 'Dukungan Textarea',
	'com:textareasupport:admin:settings:label:invalid:elements' => 'Elemen Html Terlarang',
	'com:textareasupport:admin:settings:label:invalid:elements:description' => 'Anda dapat memasukkan daftar elemen HTML di sini. Tanda koma digunakan untuk menambahkan kode lain dengan Kata Lain Pemisah Kode',
	'com:textareasupport:admin:settings:label:invalid:elements:example' => 'Contoh: <code>script, iframe, embed</code>',
);
ossn_register_languages('id', $id); 
