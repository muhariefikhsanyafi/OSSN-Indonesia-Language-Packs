<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2017 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$id = array(
	'passwordvalidation:atleast' => 'Setidaknya <em>%s<em> Panjang Karakter',
	'passwordvalidation:passwordmustbe' => 'Kata Sandi Anda harus:',
	'passwordvalidation:capitalletter' => 'berisi huruf kapital',
	'passwordvalidation:lowerletter' => "mengandung huruf kecil",
	'passwordvalidation:number' => "berisi angka",
	'passwordvalidation:error' => 'Kata sandi ini tidak memenuhi persyaratan'
);
ossn_register_languages('id', $id); 
