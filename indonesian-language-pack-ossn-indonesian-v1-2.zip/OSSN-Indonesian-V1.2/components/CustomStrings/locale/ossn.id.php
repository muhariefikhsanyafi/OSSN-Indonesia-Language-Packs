<?php

$custom_strings = array(
	'friends' => 'Teman',
	'my:own:placeholder' => 'Aku suka OSSN!'
);
ossn_register_languages('id', $custom_strings);