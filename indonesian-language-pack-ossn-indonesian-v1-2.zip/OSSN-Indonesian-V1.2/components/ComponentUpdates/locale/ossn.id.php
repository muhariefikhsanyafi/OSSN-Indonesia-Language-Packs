<?php
 $id = array(
	'component:update:update_version' => 'Perbarui Versi',
	'component:update:update_url' => 'Perbarui URL',
	'component:update:update_available' => 'Pembaruan Tersedia',
);
ossn_register_languages('id', $id); 