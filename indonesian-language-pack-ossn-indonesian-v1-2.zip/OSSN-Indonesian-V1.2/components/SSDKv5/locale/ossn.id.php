<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$id = array(
	'ssdkv5' => 'Aplikasi Seluler v5',
	
	'ssdkv5:save:error' => 'Tidak dapat menyimpan pengaturan',
	'ssdkv5:saved' => 'Pengaturan telah disimpan',
	'ssdkv5:secret' => 'Rahasia API / API Secret',
	'ssdkv5:username' => 'Nama Pengguna API / API Username',
	'ssdkv5:apikey' => 'Kunci API / API KEY',
	'ssdkv5:notes' => 'Salin kode di bawah ini dan tambahkan ke formulir permintaan API Softlab24 Anda. <a target="_blank" href="https://www.softlab24.com/mobileapi/start"><strong>Form Permintaan</strong></a>',
	
	'ssdkv5:ui:notes' => 'Silakan gunakan detail berikut saat masuk ke aplikasi kami:',
	'ssdkv5:ui:hostname' => 'Nama Host / Hostname',
	'ssdkv5:ui:username' => 'Nama Pengguna / Username',
	'ssdkv5:ui:password' => 'Kata Sandi / Password',
	
	'ssdkv5:ui:yourusername' => 'Nama pengguna Anda',
	'ssdkv5:ui:yourpassword' => 'Kata sandi Anda',
	'ssdk:mobileapp' => 'APLIKASI Seluler',
	'ssdkv5:ossnservices:required' => 'Komponen OssnServices tidak diaktifkan, Silahkan aktifkan terlebih dahulu kemudian kembali lagi kesini.',
	'ssdkv5:ossnservices:managedby' => 'OssnServices dikelola oleh komponen Mobile SDK. Pembuatan ulang kunci api dinonaktifkan!',
	
	'ssdkv5:showicons' => 'Tampilkan ikon Apple Play Store dan Google App Store di footer?',
	'ssdkv5:yes' => 'Iya',
	'ssdkv5:no' => 'Tidak',
);
ossn_register_languages('id', $id); 