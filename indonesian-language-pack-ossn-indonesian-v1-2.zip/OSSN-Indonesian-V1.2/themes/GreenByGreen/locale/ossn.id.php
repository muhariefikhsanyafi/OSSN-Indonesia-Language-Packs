<?php

$GreenByGreen_strings = array(
	'site:timepassed:data' => '%e %h %G %H:%M|en_EN.UTF-8',
	'theme:greenbygreen:dragging:instruction' => 'Catatan: Untuk hasil terbaik atur browser ke lebar gambar sampul 1040 - lebar saat ini adalah: %s',
	'theme:greenbygreen:section:menu:member' => 'Pribadi',
);
ossn_register_languages('id', $GreenByGreen_strings);