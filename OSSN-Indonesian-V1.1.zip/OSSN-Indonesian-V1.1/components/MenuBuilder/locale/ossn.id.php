<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright 2014-2019 SOFTLAB24 LIMITED
 * @license   SOFTLAB24 LIMITED, COMMERCIAL LICENSE  https://www.softlab24.com/license/commercial-license-v1
 * @link      https://www.softlab24.com/
 */
$id = array(
		'admin:menubuilder' => 'Pembuat Menu',
		'menubuilder:settings' => "Pembuat Menu",
		'menubuilder:title' => 'Teks',
		'menubuilder:url' => 'URL menu',
		'menubuilder:next' => 'Lanjut',
		'menubuilder:selecticon' => 'Pilih Icon',
		'menubuilder:save' => 'Simpan',
		'menubuilder:name' => 'Pilih Menu',
		'menubuilder:submenu' => 'Pilih Submenu',
		'menubuilder:main' => 'Utama',
		'menubuilder:menuitem:added' => 'Item menu telah ditambahkan ke dalam menu!',
		'menubuilder:menuitem:failed' => 'Item menu tidak dapat ditambahkan ke menu',
		'menubuilder:fillfields' => "Silakan isi semua kolom",
		'menubuilder:admin:name' => 'Menu',
		'menubuilder:submenu' => 'Submenu',
		'menubuilder:delete' => 'Hapus',
		'menubuilder:menuitem:delete:failed' => 'Tidak dapat menghapus item menu',
		'menubuilder:menuitem:deleted' => 'Item menu telah dihapus',
		'menubuilder:add' => 'Tambahkan Item Menu',
		'menubuilder:newtab' => 'Buka di Tab Baru',
		'menubuilder:no' => 'Tidak',
		'menubuilder:yes' => 'Iya',
		'menubuilder:invalid:url' => 'Format URL Tidak Valid',
		'menubuilder:footer' => 'Footer',
		'menubuilder:topbardropdown' => 'Topbar Dropdown (Sisi Kanan)',
		'menubuilder:topbar:dropdown' => 'Topbar Dropdown (Sisi Kanan)',
		
		'menubuilder:admin:sidemenu' => 'Administrator Topbar (Sisi Kanan)',
		'menubuilder:topbaradmin' => 'Administrator Topbar (Sisi Kiri)',
		'menubuilder:topbar:admin' => 'Administrator Topbar (Sisi Kiri)',
		'menubuilder:submenu:groups' => 'Grup',
		'menubuilder:submenu:bpage' => 'Halaman Bisnis',
		'menubuilder:submenu:polls' => 'Poling',
		'menubuilder:submenu:blogs' => 'Blog',
		'menubuilder:submenu:themes' => 'Tema',
		'menubuilder:submenu:site:settings' => 'Pengaturan Situs',
		'menubuilder:submenu:user:manager' => 'Manajer Pengguna',
		
		'menubuilder:newsfeed' => 'Bilah Samping',
		'menubuilder:submenu:onlytoplevel' => 'Utama',
		'menubuilder:submenu:components' => 'Komponen',
		'menubuilder:submenu:configure' => 'Konfigurasikan',
		'menubuilder:submenu:links' => 'Tautan',
);
ossn_register_languages('id', $id); 