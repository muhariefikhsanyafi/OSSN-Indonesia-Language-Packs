<?php

$id = array(
  'recaptcha' => 'Google reCAPTCHA',
  'recaptcha:text' => 'Silakan, isi reCAPTCHA',
  'recaptcha:error' => 'Anda telah memasukkan reCaptcha yang tidak valid',
  'recaptcha:com:site_key' => 'Google reCAPTCHA SITE_KEY',
  'recaptcha:com:secret_key' => 'Google reCAPTCHA SECRET_KEY',
  'recaptcha:com:note' => 'Kami membutuhkan kunci API, buka <a href="https://www.google.com/recaptcha/admin">https://www.google.com/recaptcha/admin</a>. Untuk mengakses halaman ini, Anda harus mengakses Akun Google Anda. Daftarkan nama situs Anda (contoh, '. ossn_site_url() . ') di mana reCAPTCHA ini akan digunakan. Setelah itu, rekatkan SECRET_KEY dan SITE_KEY di setiap bidang di sini.',
  'recaptcha:site_key:empty' => 'SITE_KEY kosong.',
  'recaptcha:secret_key:empty' => 'SECRET_KEY kosong.',
  'recaptcha:saved' => 'Kunci API disimpan.',
  'recaptcha:save:error' => 'Kunci API tidak dapat disimpan.',
);
ossn_register_languages('id', $id);