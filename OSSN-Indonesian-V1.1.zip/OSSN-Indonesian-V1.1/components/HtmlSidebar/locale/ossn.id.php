<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$id = array(
	'htmlsidebar' => 'HTML Sidebar',
	'com_htmlsidebar:entertext' => 'Masukkan HTML di sini',
	'com_htmlsidebar:admin:settings:mobile_sidebar:title' => 'Tengahkan kolom kanan di smartphone',
	'com_htmlsidebar:admin:settings:mobile_sidebar:note' => '<i class="fa fa-info-circle"></i> jika opsi ini diaktifkan, pada perangkat seluler, isi bilah sisi HTML kanan muncul di tengah sebelum pos.<br><br>',
);
ossn_register_languages('id', $id);
