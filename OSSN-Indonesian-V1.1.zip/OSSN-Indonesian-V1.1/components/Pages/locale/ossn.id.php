<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$id = array(
			'admin:cpages' => 'Halaman Khusus',
			'cpages:title' => 'Judul',
			'cpages:description' => 'Isi',
			'cpages:fillfields' => 'Silahkan isi semua kolom',
			'cpages:page:added' => 'Halaman Khusus telah dibuat',
			'cpages:page:add:failed' => 'Halaman tidak bisa ditambahkan',
			'cpages:edit' => 'Edit',
			'cpages:view' => 'Lihat',
			'cpages:delete' => 'Hapus',
			'cpages:settings' => 'Halaman Khusus',
			'cpages:settings:title' => 'Pengaturan',
			'cpages:invalid:page' => 'Halaman Tidak Valid',
			'cpages:page:saved' => 'Halaman telah disimpan',
			'cpages:page:save:failed' => 'Tidak dapat Menyimpan Halaman',
			'cpages:page:deleted' => 'Halaman telah dihapus',
			'cpages:page:delete:failed' => 'Tidak dapat menghapus Halaman',
			'cpages:addnew' => 'Tambahkan Halaman Baru',
			'cpages:pageurl' => 'URL Halaman',
			'cpages:menubuilder' => 'Anda dapat menggunakan komponen menubuilder untuk menautkan halaman di menu apa pun di situs web Anda. <a href="https://www.opensource-socialnetwork.org/component/view/3377/menubuilder" target="_bla2nk"><strong>Lihat MenuBuilder</strong></a>',
);
ossn_register_languages('id', $id); 